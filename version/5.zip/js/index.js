$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
    nav:true,
    items: 1,
    dots: true,
    nav: false
  });
});